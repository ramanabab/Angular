app.controller("ctrl",ctrl);
ctrl.$inject=["$scope"];
function ctrl($scope) {
    $scope.data = ["Hello_1","Hello_2","Hello_3","Hello_4","Hello_5"];
}